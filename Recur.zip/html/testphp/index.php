<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>


<!--
<form action="" method="post">
Name: <input type="text" name="name"><br>
<input type="submit">
</form>-->

<button onclick="msg('George')">Hi</button>

<script>
  function msg(name)
  {
    $.post(window.location, {name: name}, function(result){
      alert('hello' + name);
    });
  }
</script>
</body>
</html>
